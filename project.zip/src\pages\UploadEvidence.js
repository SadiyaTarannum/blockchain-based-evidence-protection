// ... existing code ...
<div className="upload-section">
  <h2>Upload Evidence</h2>
  <form onSubmit={handleUpload}>
    <label>Choose File:
      <input type="file" onChange={handleFileChange} required />
    </label>
    <label>AES Key:
      <input type="password" onChange={handleKeyChange} required />
    </label>
    <button type="submit">Encrypt & Upload</button>
  </form>
  {uploadStatus && <div className="status">{uploadStatus}</div>}
</div>
// ... existing code ...