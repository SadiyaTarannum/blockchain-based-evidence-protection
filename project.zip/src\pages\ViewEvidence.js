// ... existing code ...
<div className="view-section">
  <h2>View Evidence</h2>
  <form onSubmit={handleView}>
    <label>Evidence ID:
      <input type="text" onChange={handleIdChange} required />
    </label>
    <label>AES Key:
      <input type="password" onChange={handleKeyChange} required />
    </label>
    <button type="submit">Fetch & Decrypt</button>
  </form>
  {evidenceContent && <div className="evidence-content">{evidenceContent}</div>}
</div>
// ... existing code ...