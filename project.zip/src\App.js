// ... existing code ...
<div className="homepage-container">
  <h1>Blockchain Evidence Protection</h1>
  <p>Securely upload, store, and retrieve evidence using AES encryption, IPFS, and Ethereum.</p>
  <div className="actions">
    <a href="/upload" className="btn">Upload Evidence</a>
    <a href="/view" className="btn">View Evidence</a>
  </div>
</div>
// ... existing code ...